package net.sofi.caculator.model

data class FeatureButtonModel(
    val title: String,
    val route: String
)
