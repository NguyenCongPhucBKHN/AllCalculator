package net.sofi.caculator.ui.screen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import net.sofi.caculator.R
import net.sofi.caculator.ui.navigation.BasicCalCulator

@Composable
fun SplashScreen(navController: NavController) {
    // LaunchedEffect for automatic navigation after 2 seconds
    LaunchedEffect(Unit) {
        delay(2000) // Splash screen time
        navController.navigate(BasicCalCulator.route) // Navigate to Home screen
    }

    // Splash screen UI
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212)), // Background color (dark theme)
        contentAlignment = Alignment.Center
    ) {
        // Icon Image (replace with your app's logo)
        Image(
            painter = painterResource(id = R.drawable.ic_launcher_foreground), // Replace with your icon resource
            contentDescription = "App Icon",
            modifier = Modifier.size(150.dp)
        )
    }
}

