package net.sofi.caculator.model

data class BasicCalculatorResultState(
    val display: String = ""
)
